﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEPRTest1
{
    class PVCTile : Tile
    {
        public PVCTile(int id) : base(id)
        {

        }
        public bool startMiniGame()
        {
            return false;
        }
    }
}
