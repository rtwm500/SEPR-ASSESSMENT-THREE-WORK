﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEPRTest1
{
    class Player
    {
        int college;

        public Player(int college)
        {
            this.college = college;
        }
    }
}
