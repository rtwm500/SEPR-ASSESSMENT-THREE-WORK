﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bounce : MonoBehaviour {
    private GameObject targ;  
	public float speed;

    // Use this for initialization
    void Start () {
		targ = GameObject.Find ("Player");  
	}
	
	// Update is called once per frame
	void Update () {
        transform.position += transform.up * speed;
        Vector3 viewPos = Camera.main.WorldToViewportPoint(transform.position);
        viewPos.x = Mathf.Clamp01(viewPos.x);
        viewPos.y = Mathf.Clamp01(viewPos.y);
        transform.position = Camera.main.ViewportToWorldPoint(viewPos);
		int i = Random.Range (0, 2);
		int x = 0; 
		if (gameObject.tag == "Green") { 
			if (i == 1) { 
				x = 45;
			} else {  
				x = -45;
			}
		}
        if ((viewPos.x <= 0) || (viewPos.y <= 0) || (viewPos.x >= 1) || (viewPos.y >= 1)) {
            Vector3 vectorToTarget = targ.transform.position - transform.position;
            float angle = Mathf.Atan2(vectorToTarget.y, vectorToTarget.x) * Mathf.Rad2Deg - 90;
            Quaternion q = Quaternion.AngleAxis(angle+x, Vector3.forward);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, q, 999);
        }
    } 


}
