<<<<<<< HEAD
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEPRTest1
{
    class AIPlayer : Player
    {
        public AIPlayer(int college) : base(college)
        {

        }

        public void populate()
        {

        }
    }
}
=======
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEPRTest1
{
    class AIPlayer : Player
    {
        public AIPlayer(int college) : base(college)
        {





        }

        public void populate()
        {

        }

        public Boolean updateSuccessful()
        {
            return true;

        }

    }
}
>>>>>>> master
