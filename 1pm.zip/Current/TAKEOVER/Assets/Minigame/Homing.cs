﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
namespace CRGames_game
{ 
public class Homing : MonoBehaviour {
    public GameObject targ;
	public GameObject ob; 
	public Canvas can; 
	private GameObject[] spawnpoints;
	private int count;
	// Use this for initialization
	void Start () {
		spawnpoints = GameObject.FindGameObjectsWithTag ("Respawn"); 
		count = 0;
		Globals.needload = true;
		Globals.wins = 3;

	} 
	
	// Update is called once per frame
	void Update () {
		 transform.position = Vector3.MoveTowards(transform.position, targ.transform.position, 0.2f);
	} 

	void OnCollisionEnter2D(Collision2D coll)
	{ 	
		if (coll.collider.gameObject.tag == "Red") {
			//coll.gameObject.SetActive (false);  
			gameObject.SetActive(false);
			SceneManager.LoadScene("main");
		} else { 
			Globals.wins += 1;
			int i = Random.Range (0, 4);
			Instantiate(ob,spawnpoints[i].transform.position,Quaternion.identity,can.transform);
			i = Random.Range (0, 4);
			coll.gameObject.transform.SetPositionAndRotation (spawnpoints[i].transform.position,Quaternion.identity);
			switch (count) { 
			case 0:
				coll.gameObject.GetComponentInChildren<Text> ().text = "V";   
				count += 1;
				break; 
			case 1: 
				coll.gameObject.GetComponentInChildren<Text> ().text = "C";   
				count += 1;
				break;
				default: 
					coll.gameObject.SetActive (false);  
					SceneManager.LoadScene("main");
				break; 
			}
		}
	}

	}
}
