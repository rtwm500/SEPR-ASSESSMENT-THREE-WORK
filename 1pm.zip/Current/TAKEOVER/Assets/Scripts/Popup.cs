﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Popup : MonoBehaviour {

	//Define 200x130 px window will apear in the center of the screen.
	private Rect windowRect;
	//Define a bool that will show/hide the popup
	private bool show = false;		
	private string[] text;
	private string popupname; 
	private string func1;
	private string func2; 
	private GameObject ParentObject;

	void OnGUI () 
	{
		if(show)																	//Whenever show is set to true make the window appear, when false hide it
			windowRect = GUI.Window (0, windowRect, DialogWindow, popupname);	//Set title of box
	}


	void DialogWindow (int windowID)
	{
		float y = 20;
		for (int i = 0; i <text.Length-2;i++){
			
			GUI.Label (new Rect (5, y+(i*20), windowRect.width, 20), text[i]); //Set first line of description
		}				//Set second line of description

		if(GUI.Button(new Rect(5,y+15+((text.Length-2)*20), windowRect.width - 10, 20), text[text.Length-2]))					//Define one button that says "Continue anyway"
		{													//Calls conflict resolution
			ParentObject.BroadcastMessage(func1);
			show = false;																				//And closes popup when clicked	
		}

		if(GUI.Button(new Rect(5,y+40+((text.Length-2)*20), windowRect.width - 10, 20), text[text.Length-1]))					//Define one button that says "Select new move"
		{	
			if (func2 != null){	
			ParentObject.BroadcastMessage(func2);	//And closes popup when clicked	
			}
			show = false;
		}
	}

	// To open the dialogue from outside of the script.
	public void Open(string title, string[] lines, string f1, string f2, GameObject Parent)
	{ 
		func1 = f1; 
		func2 = f2;
		popupname = title;
		text = lines; 
		ParentObject = Parent;
		windowRect = new Rect ((Screen.width - 200)/2, (Screen.height - (text.Length*20)+50)/2, 200, (text.Length*20)+50);
		show = true;
	} 
		

}
