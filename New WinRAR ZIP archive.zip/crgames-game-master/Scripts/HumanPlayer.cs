﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEPRTest1
{
    class HumanPlayer : Player
    {
        int currency = 0;
        int researchPoints = 0;
        bool hasPVC = false;

        public HumanPlayer(int college) : base(college)
        {

        }

        public void upgrade()
        {

        }

        public void research()
        {

        }
    }
}
